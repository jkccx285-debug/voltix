# -*- coding: utf-8 -*-
"""
Voltix — آزمایشگاه و دستیار آموزشی الکترونیک
یک برنامه آموزشی فارسی برای هنرجویان الکترونیک هنرستان
"""

import io
import math
import re
from typing import Dict, List, Tuple, Optional

import numpy as np
import pandas as pd
import streamlit as st

# کتابخانه‌های اختیاری/اصلی هوش مصنوعی
try:
    from pypdf import PdfReader
except Exception:
    PdfReader = None

try:
    import faiss
except Exception:
    faiss = None

try:
    from google import genai
    from google.genai import types
except Exception:
    genai = None
    types = None


# ============================================================
# تنظیمات عمومی
# ============================================================

st.set_page_config(
    page_title="Voltix | آزمایشگاه الکترونیک",
    page_icon="⚡",
    layout="wide",
    initial_sidebar_state="expanded",
)

# پالت ملایم و CSS کاملاً داخل برنامه؛ بدون نیاز به فایل خارجی
st.markdown(
    """
<style>
@import url('https://fonts.googleapis.com/css2?family=Vazirmatn:wght@400;500;600;700;800&display=swap');

html, body, [class*="css"], .stApp {
    font-family: "Vazirmatn", Tahoma, Arial, sans-serif !important;
    direction: rtl;
}

.stApp {
    background: linear-gradient(180deg, #f7f9fc 0%, #eef3f8 100%);
}

[data-testid="stSidebar"] {
    background: #ffffff;
    border-left: 1px solid #e7edf4;
}

.block-container {
    max-width: 1250px;
    padding-top: 1.3rem;
    padding-bottom: 3rem;
}

h1, h2, h3, h4 {
    font-family: "Vazirmatn", Tahoma, sans-serif !important;
    letter-spacing: -0.3px;
}

.hero {
    padding: 1.4rem 1.5rem;
    border-radius: 22px;
    background: linear-gradient(135deg, #ffffff 0%, #eaf4ff 100%);
    border: 1px solid #dce8f5;
    box-shadow: 0 8px 30px rgba(28, 52, 84, .06);
    margin-bottom: 1rem;
}

.hero-title {
    font-size: 2.2rem;
    font-weight: 800;
    color: #17324d;
    margin-bottom: .25rem;
}

.hero-subtitle {
    color: #52677d;
    font-size: 1rem;
    line-height: 1.9;
}

.card {
    background: #ffffff;
    border: 1px solid #e4ebf3;
    border-radius: 18px;
    padding: 1rem 1.1rem;
    margin: .45rem 0;
    box-shadow: 0 5px 18px rgba(28, 52, 84, .04);
}

.result {
    background: #eef8f3;
    border: 1px solid #ccebdc;
    border-radius: 16px;
    padding: 1rem;
    color: #174c35;
    margin-top: .7rem;
}

.formula {
    background: #f7f7fb;
    border-right: 4px solid #6c7ee1;
    border-radius: 12px;
    padding: .8rem 1rem;
    direction: ltr;
    text-align: center;
    font-family: "DejaVu Sans", monospace;
    margin: .7rem 0;
}

.small-muted {
    color: #718096;
    font-size: .88rem;
}

.footer {
    text-align: center;
    color: #718096;
    padding: 1.5rem 0 .5rem;
    font-size: .88rem;
}

.pinout {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(110px, 1fr));
    gap: .55rem;
    margin-top: .7rem;
}

.pin {
    background: #f8fafc;
    border: 1px solid #e5ebf2;
    border-radius: 12px;
    padding: .7rem;
    text-align: center;
}

.wire {
    height: 4px;
    background: #475569;
    border-radius: 10px;
    margin: .7rem 0;
}

.component-svg {
    width: 100%;
    max-width: 620px;
    height: auto;
    display: block;
    margin: .4rem auto;
}

@media (max-width: 700px) {
    .hero-title { font-size: 1.7rem; }
    .block-container { padding-left: .7rem; padding-right: .7rem; }
    .stButton button, .stDownloadButton button { width: 100%; }
}
</style>
""",
    unsafe_allow_html=True,
)


# ============================================================
# داده‌های قطعات
# ============================================================

RESISTOR_COLORS = {
    "مشکی": (0, 1, None, 250),
    "قهوه‌ای": (1, 10, 1, 100),
    "قرمز": (2, 100, 2, 50),
    "نارنجی": (3, 1_000, 15, None),
    "زرد": (4, 10_000, 25, None),
    "سبز": (5, 100_000, 0.5, None),
    "آبی": (6, 1_000_000, 0.25, None),
    "بنفش": (7, 10_000_000, 0.1, None),
    "خاکستری": (8, 100_000_000, 0.05, None),
    "سفید": (9, 1_000_000_000, 0.02, None),
    "طلایی": (None, 0.1, 5, None),
    "نقره‌ای": (None, 0.01, 10, None),
}

COMPONENTS = [
    {
        "نوع": "ترانزیستور",
        "نام": "BC547",
        "پایه‌ها": "1=C، 2=B، 3=E در پکیج TO-92 رایج؛ حتماً دیتاشیت سازنده را بررسی کنید.",
        "مشخصات": "NPN، سیگنال کوچک، Vce حدود 45V، مناسب تقویت و سوئیچینگ سبک.",
        "کاربرد": "تقویت‌کننده کوچک، سنسورها، سوئیچ منطقی.",
    },
    {
        "نوع": "ترانزیستور",
        "نام": "BC557",
        "پایه‌ها": "1=C، 2=B، 3=E در آرایش رایج؛ ترتیب واقعی را با دیتاشیت سازنده چک کنید.",
        "مشخصات": "PNP، سیگنال کوچک، Vce حدود 45V.",
        "کاربرد": "تقویت و سوئیچینگ سمت مثبت.",
    },
    {
        "نوع": "ترانزیستور",
        "نام": "2N2222",
        "پایه‌ها": "آرایش پایه بسته به سازنده و پکیج متفاوت است؛ دیتاشیت قطعه خود را ملاک قرار دهید.",
        "مشخصات": "NPN، سیگنال کوچک و سوئیچینگ.",
        "کاربرد": "درایو LED، رله‌های کوچک، تقویت سیگنال.",
    },
    {
        "نوع": "ترانزیستور",
        "نام": "2N3904",
        "پایه‌ها": "در پکیج TO-92 رایج، ترتیب پایه را با دیتاشیت سازنده بررسی کنید.",
        "مشخصات": "NPN، سیگنال کوچک.",
        "کاربرد": "تقویت، سوئیچینگ و مدارهای آموزشی.",
    },
    {
        "نوع": "ترانزیستور",
        "نام": "IRF540",
        "پایه‌ها": "G=Gate، D=Drain، S=Source؛ ترتیب فیزیکی را با دیتاشیت سازنده بررسی کنید.",
        "مشخصات": "MOSFET کانال N، مناسب جریان‌های بالاتر؛ برای گیت 5V همیشه انتخاب ایده‌آلی نیست.",
        "کاربرد": "سوئیچ قدرت، موتور و بارهای DC.",
    },
    {
        "نوع": "آی‌سی",
        "نام": "LM358",
        "پایه‌ها": "1=OUT1، 2=IN1-، 3=IN1+، 4=V-، 5=IN2+، 6=IN2-، 7=OUT2، 8=V+",
        "مشخصات": "تقویت‌کننده عملیاتی دوگانه.",
        "کاربرد": "تقویت، مقایسه، فیلتر و سنجش.",
    },
    {
        "نوع": "آی‌سی",
        "نام": "LM741",
        "پایه‌ها": "1=Offset، 2=IN-، 3=IN+، 4=V-، 5=Offset، 6=OUT، 7=V+، 8=NC",
        "مشخصات": "تقویت‌کننده عملیاتی کلاسیک.",
        "کاربرد": "آموزش اصول آپ‌امپ و مدارهای آنالوگ.",
    },
    {
        "نوع": "آی‌سی",
        "نام": "LM7805",
        "پایه‌ها": "در TO-220 رایج: 1=IN، 2=GND، 3=OUT؛ سازنده را بررسی کنید.",
        "مشخصات": "رگولاتور خطی 5V.",
        "کاربرد": "تغذیه مدارهای 5 ولتی.",
    },
    {
        "نوع": "آی‌سی",
        "نام": "NE555",
        "پایه‌ها": "1=GND، 2=TRIG، 3=OUT، 4=RESET، 5=CTRL، 6=THR، 7=DIS، 8=VCC",
        "مشخصات": "تایمر/مولتی‌ویبراتور بسیار رایج.",
        "کاربرد": "پالس، PWM، نوسان‌ساز و تأخیر زمانی.",
    },
    {
        "نوع": "آی‌سی",
        "نام": "CD4017",
        "پایه‌ها": "آی‌سی شمارنده ده‌دهی با خروجی‌های Q0 تا Q9؛ شماره پایه‌ها را با دیتاشیت مدل دقیق تطبیق دهید.",
        "مشخصات": "ده‌دهی/جانسون، CMOS.",
        "کاربرد": "شمارنده، LED رقصان و تقسیم فرکانس.",
    },
    {
        "نوع": "دیود",
        "نام": "1N4007",
        "پایه‌ها": "کاتد معمولاً با نوار مشخص می‌شود.",
        "مشخصات": "دیود یکسوساز عمومی، ولتاژ معکوس نامی بالا.",
        "کاربرد": "یکسوسازی و حفاظت پلاریته.",
    },
    {
        "نوع": "دیود",
        "نام": "1N4148",
        "پایه‌ها": "کاتد با نوار مشخص می‌شود.",
        "مشخصات": "دیود سیگنال سریع.",
        "کاربرد": "سوئیچینگ و مدارهای منطقی/سیگنال.",
    },
    {
        "نوع": "دیود",
        "نام": "LED",
        "پایه‌ها": "آند + و کاتد -؛ در بسیاری از LEDها پایه بلندتر آند است.",
        "مشخصات": "دیود نوردهنده، رنگ و Vf وابسته به نوع LED.",
        "کاربرد": "نمایش، اعلان و روشنایی.",
    },
    {
        "نوع": "دیود",
        "نام": "Zener",
        "پایه‌ها": "کاتد با نوار مشخص می‌شود.",
        "مشخصات": "دیود زنر برای تثبیت/محدودسازی ولتاژ در ناحیه شکست.",
        "کاربرد": "مرجع ولتاژ و حفاظت.",
    },
]

E12 = [10, 12, 15, 18, 22, 27, 33, 39, 47, 56, 68, 82]
E24 = [10, 11, 12, 13, 15, 16, 18, 20, 22, 24, 27, 30, 33, 36, 39, 43, 47, 51, 56, 62, 68, 75, 82, 91]

CAP_TYPES = {
    "سرامیکی": "کوچک، سریع و مناسب فرکانس‌های بالاتر و بای‌پس.",
    "الکترولیتی": "ظرفیت بالا، معمولاً قطب‌دار؛ برای تغذیه و ذخیره انرژی رایج.",
    "تانتالیوم": "ظرفیت/حجم مناسب و قطب‌دار؛ نسبت به اضافه‌ولتاژ حساس.",
}


# ============================================================
# توابع کمکی
# ============================================================

def fmt(value: float, unit: str = "") -> str:
    """نمایش عدد با واحد به شکل خوانا."""
    if value == 0:
        return f"0 {unit}".strip()
    av = abs(value)
    prefixes = [
        (1e12, "T"),
        (1e9, "G"),
        (1e6, "M"),
        (1e3, "k"),
        (1, ""),
        (1e-3, "m"),
        (1e-6, "µ"),
        (1e-9, "n"),
        (1e-12, "p"),
    ]
    for factor, prefix in prefixes:
        if av >= factor:
            return f"{value / factor:.5g} {prefix}{unit}".strip()
    return f"{value:.5g} {unit}".strip()


def safe_float(label: str, value: float, minimum: Optional[float] = None) -> Optional[float]:
    """اعتبارسنجی ساده ورودی‌های عددی."""
    try:
        x = float(value)
        if not math.isfinite(x):
            raise ValueError
        if minimum is not None and x < minimum:
            raise ValueError
        return x
    except Exception:
        st.error(f"مقدار «{label}» معتبر نیست.")
        return None


def card(title: str, body: str):
    st.markdown(
        f'<div class="card"><h3>{title}</h3><div>{body}</div></div>',
        unsafe_allow_html=True,
    )


def result_box(text: str):
    st.markdown(f'<div class="result">{text}</div>', unsafe_allow_html=True)


def formula(text: str):
    st.markdown(f'<div class="formula">{text}</div>', unsafe_allow_html=True)


def circuit_svg(kind: str) -> str:
    """چند شماتیک ساده SVG؛ مستقل از تصویر خارجی و مناسب موبایل."""
    if kind == "divider":
        return """
        <svg class="component-svg" viewBox="0 0 700 230" xmlns="http://www.w3.org/2000/svg">
          <line x1="350" y1="15" x2="350" y2="45" stroke="#475569" stroke-width="5"/>
          <rect x="320" y="45" width="60" height="55" rx="8" fill="#e2e8f0" stroke="#475569" stroke-width="4"/>
          <text x="350" y="79" text-anchor="middle" font-size="22" font-family="Arial">R1</text>
          <line x1="350" y1="100" x2="350" y2="125" stroke="#475569" stroke-width="5"/>
          <circle cx="350" cy="125" r="6" fill="#2563eb"/>
          <text x="375" y="132" font-size="20" font-family="Arial">Vout</text>
          <rect x="320" y="140" width="60" height="55" rx="8" fill="#e2e8f0" stroke="#475569" stroke-width="4"/>
          <text x="350" y="174" text-anchor="middle" font-size="22" font-family="Arial">R2</text>
          <line x1="350" y1="195" x2="350" y2="220" stroke="#475569" stroke-width="5"/>
          <text x="350" y="32" text-anchor="middle" font-size="18" font-family="Arial">Vin</text>
          <text x="350" y="226" text-anchor="middle" font-size="18" font-family="Arial">GND</text>
        </svg>
        """
    if kind == "led":
        return """
        <svg class="component-svg" viewBox="0 0 700 230" xmlns="http://www.w3.org/2000/svg">
          <text x="70" y="120" font-size="22" font-family="Arial">Vcc</text>
          <line x1="120" y1="115" x2="215" y2="115" stroke="#475569" stroke-width="5"/>
          <rect x="215" y="87" width="110" height="55" rx="8" fill="#e2e8f0" stroke="#475569" stroke-width="4"/>
          <text x="270" y="122" text-anchor="middle" font-size="22" font-family="Arial">R</text>
          <line x1="325" y1="115" x2="385" y2="115" stroke="#475569" stroke-width="5"/>
          <polygon points="385,85 385,145 445,115" fill="#fde68a" stroke="#475569" stroke-width="4"/>
          <line x1="455" y1="85" x2="455" y2="145" stroke="#475569" stroke-width="5"/>
          <line x1="455" y1="115" x2="580" y2="115" stroke="#475569" stroke-width="5"/>
          <line x1="580" y1="115" x2="580" y2="185" stroke="#475569" stroke-width="5"/>
          <text x="420" y="75" font-size="20" font-family="Arial">LED</text>
          <text x="580" y="210" text-anchor="middle" font-size="18" font-family="Arial">GND</text>
        </svg>
        """
    if kind == "switch":
        return """
        <svg class="component-svg" viewBox="0 0 700 240" xmlns="http://www.w3.org/2000/svg">
          <circle cx="130" cy="150" r="22" fill="#fff" stroke="#475569" stroke-width="4"/>
          <line x1="152" y1="150" x2="265" y2="150" stroke="#475569" stroke-width="5"/>
          <rect x="265" y="120" width="90" height="60" rx="8" fill="#e2e8f0" stroke="#475569" stroke-width="4"/>
          <text x="310" y="157" text-anchor="middle" font-size="22" font-family="Arial">RB</text>
          <line x1="355" y1="150" x2="420" y2="150" stroke="#475569" stroke-width="5"/>
          <polygon points="420,100 420,200 500,150" fill="#dbeafe" stroke="#475569" stroke-width="4"/>
          <text x="460" y="90" text-anchor="middle" font-size="20" font-family="Arial">NPN</text>
          <line x1="500" y1="150" x2="590" y2="150" stroke="#475569" stroke-width="5"/>
          <line x1="590" y1="150" x2="590" y2="210" stroke="#475569" stroke-width="5"/>
          <text x="115" y="120" font-size="18" font-family="Arial">Vin</text>
          <text x="590" y="232" text-anchor="middle" font-size="18" font-family="Arial">GND</text>
        </svg>
        """
    return ""


def unit_to_base(value: float, unit: str, category: str) -> float:
    factors = {
        "مقاومت": {"Ω": 1, "kΩ": 1e3, "MΩ": 1e6},
        "خازن": {"pF": 1e-12, "nF": 1e-9, "µF": 1e-6, "mF": 1e-3, "F": 1},
        "ولتاژ": {"mV": 1e-3, "V": 1, "kV": 1e3},
        "جریان": {"µA": 1e-6, "mA": 1e-3, "A": 1},
    }
    return value * factors[category][unit]


def resistor_value_from_bands(bands: List[str], five_band: bool) -> Tuple[float, float]:
    if five_band:
        d1 = RESISTOR_COLORS[bands[0]][0]
        d2 = RESISTOR_COLORS[bands[1]][0]
        d3 = RESISTOR_COLORS[bands[2]][0]
        mult = RESISTOR_COLORS[bands[3]][1]
        tol = RESISTOR_COLORS[bands[4]][2]
        return ((d1 * 100 + d2 * 10 + d3) * mult, tol)
    d1 = RESISTOR_COLORS[bands[0]][0]
    d2 = RESISTOR_COLORS[bands[1]][0]
    mult = RESISTOR_COLORS[bands[2]][1]
    tol = RESISTOR_COLORS[bands[3]][2]
    return ((d1 * 10 + d2) * mult, tol)


def color_css(name: str) -> str:
    return {
        "مشکی": "#111827",
        "قهوه‌ای": "#8b5a2b",
        "قرمز": "#ef4444",
        "نارنجی": "#f97316",
        "زرد": "#facc15",
        "سبز": "#22c55e",
        "آبی": "#3b82f6",
        "بنفش": "#8b5cf6",
        "خاکستری": "#9ca3af",
        "سفید": "#ffffff",
        "طلایی": "#d4af37",
        "نقره‌ای": "#c0c0c0",
    }[name]


def resistor_visual(bands: List[str]) -> str:
    spans = []
    for c in bands:
        spans.append(
            f'<span style="display:inline-block;width:28px;height:75px;'
            f'background:{color_css(c)};border:1px solid #64748b;margin:0 3px;"></span>'
        )
    return (
        '<div style="display:flex;justify-content:center;align-items:center;'
        'background:#d6b98c;border-radius:12px;padding:12px;max-width:310px;'
        'margin:10px auto;">'
        + "".join(spans)
        + "</div>"
    )


# ============================================================
# تب ۱: ماشین‌حساب‌ها
# ============================================================

def tab_calculators():
    st.header("🧮 ماشین‌حساب‌های الکترونیک")
    subtabs = st.tabs([
        "قانون اهم", "کد رنگ مقاومت", "تقسیم ولتاژ",
        "LED", "خازن", "فیلتر RC"
    ])

    # قانون اهم
    with subtabs[0]:
        st.subheader("ماشین‌حساب قانون اهم")
        st.caption("حداقل دو مقدار را وارد کنید؛ مقدار سوم به‌صورت خودکار محاسبه می‌شود.")
        c1, c2, c3 = st.columns(3)
        with c1:
            v = st.number_input("ولتاژ V", min_value=0.0, value=5.0, step=0.1)
        with c2:
            i = st.number_input("جریان A", min_value=0.0, value=0.01, step=0.001, format="%.6f")
        with c3:
            r = st.number_input("مقاومت Ω", min_value=0.0, value=500.0, step=10.0)

        provided = sum(x > 0 for x in [v, i, r])
        if provided < 2:
            st.info("دو مقدار مثبت وارد کنید.")
        else:
            if v > 0 and i > 0:
                rr = v / i
                formula("V = I × R")
                result_box(f"<b>مقاومت:</b> {fmt(rr, 'Ω')}")
            elif v > 0 and r > 0:
                ii = v / r
                formula("I = V / R")
                result_box(f"<b>جریان:</b> {fmt(ii, 'A')}")
            elif i > 0 and r > 0:
                vv = i * r
                formula("V = I × R")
                result_box(f"<b>ولتاژ:</b> {fmt(vv, 'V')}")

    # کد رنگ
    with subtabs[1]:
        st.subheader("ماشین‌حساب کد رنگ مقاومت")
        mode = st.radio("نوع مقاومت", ["۴ نواری", "۵ نواری"], horizontal=True)
        five = mode == "۵ نواری"
        colors_digits = ["مشکی", "قهوه‌ای", "قرمز", "نارنجی", "زرد",
                         "سبز", "آبی", "بنفش", "خاکستری", "سفید"]
        if five:
            cols = st.columns(5)
            bands = [
                cols[0].selectbox("نوار ۱", colors_digits, index=1),
                cols[1].selectbox("نوار ۲", colors_digits, index=0),
                cols[2].selectbox("نوار ۳", colors_digits, index=0),
                cols[3].selectbox("ضریب", list(RESISTOR_COLORS.keys()), index=2),
                cols[4].selectbox("تلورانس", ["قهوه‌ای", "قرمز", "سبز", "آبی", "بنفش", "خاکستری", "طلایی", "نقره‌ای"], index=6),
            ]
        else:
            cols = st.columns(4)
            bands = [
                cols[0].selectbox("نوار ۱", colors_digits, index=1),
                cols[1].selectbox("نوار ۲", colors_digits, index=0),
                cols[2].selectbox("ضریب", list(RESISTOR_COLORS.keys()), index=2),
                cols[3].selectbox("تلورانس", ["قهوه‌ای", "قرمز", "سبز", "آبی", "بنفش", "خاکستری", "طلایی", "نقره‌ای"], index=6),
            ]
        try:
            value, tol = resistor_value_from_bands(bands, five)
            st.markdown(resistor_visual(bands), unsafe_allow_html=True)
            result_box(f"<b>مقدار:</b> {fmt(value, 'Ω')}<br><b>تلورانس:</b> ±{tol}%")
        except Exception:
            st.error("ترکیب نوارها معتبر نیست.")

    # تقسیم ولتاژ
    with subtabs[2]:
        st.subheader("ماشین‌حساب تقسیم ولتاژ")
        c1, c2, c3 = st.columns(3)
        vin = c1.number_input("Vin (V)", min_value=0.0, value=12.0, step=0.5)
        r1 = c2.number_input("R1 (Ω)", min_value=0.000001, value=10000.0, step=1000.0)
        r2 = c3.number_input("R2 (Ω)", min_value=0.000001, value=10000.0, step=1000.0)
        vout = vin * r2 / (r1 + r2)
        st.markdown(circuit_svg("divider"), unsafe_allow_html=True)
        formula("Vout = Vin × R2 / (R1 + R2)")
        result_box(f"<b>Vout = {fmt(vout, 'V')}</b>")

    # LED
    with subtabs[3]:
        st.subheader("ماشین‌حساب مقاومت LED")
        c1, c2, c3 = st.columns(3)
        vs = c1.number_input("ولتاژ منبع (V)", min_value=0.0, value=5.0, step=0.1)
        vf = c2.number_input("ولتاژ LED (V)", min_value=0.0, value=2.0, step=0.1)
        il_ma = c3.number_input("جریان LED (mA)", min_value=0.01, value=10.0, step=1.0)
        il = il_ma / 1000
        st.markdown(circuit_svg("led"), unsafe_allow_html=True)
        if vs <= vf:
            st.error("ولتاژ منبع باید از ولتاژ LED بیشتر باشد.")
        else:
            rr = (vs - vf) / il
            power = (vs - vf) * il
            formula("R = (Vs − Vf) / I")
            result_box(f"<b>مقاومت لازم:</b> {fmt(rr, 'Ω')}<br><b>توان روی مقاومت:</b> {fmt(power, 'W')}")

    # خازن
    with subtabs[4]:
        st.subheader("ماشین‌حساب خازن")
        mode = st.selectbox("نوع محاسبه", ["سری", "موازی", "شارژ Q = CV", "انرژی E = ½CV²"])
        if mode in ["سری", "موازی"]:
            n = st.number_input("تعداد خازن‌ها", min_value=2, max_value=8, value=3, step=1)
            vals = []
            cols = st.columns(int(n))
            for idx in range(int(n)):
                vals.append(cols[idx].number_input(f"C{idx+1} (µF)", min_value=0.000001, value=float(idx + 1), step=0.1))
            c = [x * 1e-6 for x in vals]
            if mode == "موازی":
                ceq = sum(c)
                formula("Ceq = C1 + C2 + ...")
            else:
                ceq = 1 / sum(1 / x for x in c)
                formula("1/Ceq = 1/C1 + 1/C2 + ...")
            result_box(f"<b>ظرفیت معادل:</b> {fmt(ceq, 'F')}")
        elif mode == "شارژ Q = CV":
            c = st.number_input("ظرفیت C (µF)", min_value=0.000001, value=100.0, step=1.0) * 1e-6
            v = st.number_input("ولتاژ V", min_value=0.0, value=5.0, step=0.1)
            q = c * v
            formula("Q = C × V")
            result_box(f"<b>بار:</b> {fmt(q, 'C')}")
        else:
            c = st.number_input("ظرفیت C (µF)", min_value=0.000001, value=100.0, step=1.0) * 1e-6
            v = st.number_input("ولتاژ V", min_value=0.0, value=5.0, step=0.1)
            e = 0.5 * c * v * v
            formula("E = ½ C V²")
            result_box(f"<b>انرژی:</b> {fmt(e, 'J')}")

    # فیلتر RC
    with subtabs[5]:
        st.subheader("ماشین‌حساب فیلتر RC")
        c1, c2 = st.columns(2)
        r = c1.number_input("R (Ω)", min_value=0.000001, value=10000.0, step=1000.0)
        c = c2.number_input("C (µF)", min_value=0.000001, value=0.1, step=0.01)
        c_f = c * 1e-6
        fc = 1 / (2 * math.pi * r * c_f)
        formula("fc = 1 / (2πRC)")
        result_box(f"<b>فرکانس قطع:</b> {fmt(fc, 'Hz')}")


# ============================================================
# تب ۲: مرجع قطعات
# ============================================================

def tab_reference():
    st.header("📚 مرجع قطعات")
    sub = st.tabs(["ترانزیستورها", "آی‌سی‌ها", "دیودها", "مقاومت‌ها", "خازن‌ها", "جستجوی قطعات"])

    def show_rows(kind):
        rows = [x for x in COMPONENTS if x["نوع"] == kind]
        for item in rows:
            with st.expander(f'{item["نام"]}'):
                st.write(f'**پایه‌ها:** {item["پایه‌ها"]}')
                st.write(f'**مشخصات:** {item["مشخصات"]}')
                st.write(f'**کاربرد:** {item["کاربرد"]}')

    with sub[0]:
        show_rows("ترانزیستور")
    with sub[1]:
        show_rows("آی‌سی")
    with sub[2]:
        show_rows("دیود")
    with sub[3]:
        st.subheader("سری E12")
        e12_rows = []
        for p in E12:
            e12_rows.append([f"{p}×10⁰", f"{p}×10¹", f"{p}×10²", f"{p}×10³", f"{p}×10⁴", f"{p}×10⁵"])
        st.dataframe(pd.DataFrame(e12_rows, columns=["Ω", "×10", "×100", "×1k", "×10k", "×100k"]), use_container_width=True)
        st.subheader("سری E24")
        st.dataframe(pd.DataFrame({"مقادیر پایه": E24}), use_container_width=True)
    with sub[4]:
        for name, desc in CAP_TYPES.items():
            card(name, desc)
        st.markdown("""
        **نکته درباره کد رنگی خازن:** کدگذاری بین سازندگان و خانواده‌های مختلف یکسان نیست.
        برای خازن‌های قدیمی یا خاص، مقدار درج‌شده روی بدنه و دیتاشیت سازنده را اولویت بدهید.
        """)
    with sub[5]:
        q = st.text_input("🔎 نام قطعه را جستجو کنید", placeholder="مثلاً NE555 یا 1N4148")
        typ = st.multiselect("فیلتر نوع", sorted({x["نوع"] for x in COMPONENTS}), default=[])
        data = COMPONENTS
        if typ:
            data = [x for x in data if x["نوع"] in typ]
        if q:
            data = [x for x in data if q.lower() in x["نام"].lower() or q in x["نام"]]
        if data:
            st.dataframe(pd.DataFrame(data), use_container_width=True)
        else:
            st.info("قطعه‌ای پیدا نشد.")


# ============================================================
# تب ۳: آموزش تعاملی
# ============================================================

def tab_learning():
    st.header("🎓 آموزش تعاملی")
    sub = st.tabs(["سری و موازی", "AC و DC", "ترانزیستور به‌عنوان کلید", "تست دیود", "شبیه‌ساز قانون اهم"])

    with sub[0]:
        st.subheader("سری vs موازی")
        mode = st.radio("آرایش مدار", ["سری", "موازی"], horizontal=True)
        r1 = st.slider("R1 (Ω)", 10, 1000, 100)
        r2 = st.slider("R2 (Ω)", 10, 1000, 200)
        v = st.slider("منبع (V)", 1, 24, 12)
        if mode == "سری":
            req = r1 + r2
            current = v / req
            v1, v2 = current * r1, current * r2
            formula("Rtotal = R1 + R2")
            result_box(f"Rtotal = {fmt(req,'Ω')}<br>I = {fmt(current,'A')}<br>V1 = {fmt(v1,'V')} | V2 = {fmt(v2,'V')}")
        else:
            req = 1 / (1 / r1 + 1 / r2)
            current_total = v / req
            i1, i2 = v / r1, v / r2
            formula("1/Rtotal = 1/R1 + 1/R2")
            result_box(f"Rtotal = {fmt(req,'Ω')}<br>I کل = {fmt(current_total,'A')}<br>I1 = {fmt(i1,'A')} | I2 = {fmt(i2,'A')}")

    with sub[1]:
        st.subheader("AC و DC")
        mode = st.radio("نوع موج", ["DC", "AC"], horizontal=True)
        amp = st.slider("دامنه", 1.0, 10.0, 5.0, .5)
        n = 120
        x = np.linspace(0, 2 * math.pi, n)
        y = np.full(n, amp) if mode == "DC" else amp * np.sin(2 * x)
        chart = pd.DataFrame({"نمونه": np.arange(n), "ولتاژ": y}).set_index("نمونه")
        st.line_chart(chart, height=280)
        if mode == "DC":
            st.info("DC جهت و مقدار ثابت یا تقریباً ثابت دارد؛ باتری یک نمونه رایج است.")
        else:
            st.info("AC به‌طور دوره‌ای تغییر می‌کند؛ برق شبکه نمونه شناخته‌شده‌ای از AC است.")

    with sub[2]:
        st.subheader("ترانزیستور NPN به‌عنوان کلید")
        st.markdown(circuit_svg("switch"), unsafe_allow_html=True)
        vb = st.number_input("ولتاژ فرمان پایه Vb (V)", min_value=0.0, value=5.0, step=.1)
        rb = st.number_input("مقاومت پایه Rb (Ω)", min_value=1.0, value=1000.0, step=100.0)
        vbe = st.number_input("VBE تقریبی (V)", min_value=0.1, value=.7, step=.05)
        beta = st.number_input("بتای تقریبی", min_value=1.0, value=100.0, step=5.0)
        ib = max((vb - vbe) / rb, 0)
        ic = beta * ib
        formula("IB ≈ (VB − VBE) / RB    و    IC ≈ β × IB")
        result_box(f"IB ≈ {fmt(ib,'A')}<br>IC نظری ≈ {fmt(ic,'A')}<br><span class='small-muted'>در عمل، اشباع ترانزیستور و محدودیت بار باید بررسی شود.</span>")

    with sub[3]:
        st.subheader("دیود — تست جهت")
        anode = st.selectbox("سمت مثبت منبع به کدام پایه وصل است؟", ["آند", "کاتد"])
        threshold = st.slider("ولتاژ منبع (V)", 0.0, 10.0, 5.0, .1)
        if anode == "آند" and threshold >= .6:
            st.success("دیود در این مدل آموزشی در بایاس مستقیم است و می‌تواند هدایت کند.")
        else:
            st.warning("دیود در این مدل آموزشی هدایت عادی ندارد.")
        st.caption("این شبیه‌سازی آموزشی است؛ افت واقعی دیود به نوع، جریان و دما وابسته است.")

    with sub[4]:
        st.subheader("شبیه‌ساز زنده قانون اهم")
        v = st.slider("ولتاژ (V)", 0.0, 24.0, 12.0, .1)
        r = st.slider("مقاومت (Ω)", 1.0, 2000.0, 100.0, 1.0)
        i = v / r
        formula("I = V / R")
        result_box(f"<b>I = {fmt(i,'A')}</b>")
        chart = pd.DataFrame({"V": [v], "R": [r], "I": [i]})
        st.dataframe(chart, use_container_width=True)


# ============================================================
# تب ۴: دستیار هوشمند RAG با Gemini
# ============================================================

def get_gemini_client(api_key: str):
    if not genai:
        return None
    return genai.Client(api_key=api_key)


def extract_pdf_pages(uploaded_file) -> List[Dict]:
    if PdfReader is None:
        raise RuntimeError("کتابخانه pypdf نصب نشده است.")
    reader = PdfReader(io.BytesIO(uploaded_file.getvalue()))
    pages = []
    for page_no, page in enumerate(reader.pages, start=1):
        try:
            text = page.extract_text() or ""
        except Exception:
            text = ""
        text = re.sub(r"\s+", " ", text).strip()
        if text:
            pages.append({"page": page_no, "text": text})
    return pages


def chunk_pages(pages: List[Dict], chunk_size: int = 900, overlap: int = 120) -> List[Dict]:
    chunks = []
    for p in pages:
        text = p["text"]
        start = 0
        while start < len(text):
            end = min(len(text), start + chunk_size)
            part = text[start:end]
            chunks.append({"page": p["page"], "text": part})
            if end >= len(text):
                break
            start = max(0, end - overlap)
    return chunks


def embed_texts(client, texts: List[str]) -> np.ndarray:
    """Embedding با Gemini؛ در صورت تغییر SDK، خطا را به رابط کاربری منتقل می‌کند."""
    vectors = []
    for text in texts:
        response = client.models.embed_content(
            model="gemini-embedding-001",
            contents=text,
        )
        emb = getattr(response, "embeddings", None)
        if emb:
            vec = getattr(emb[0], "values", None)
        else:
            vec = None
        if vec is None:
            raise RuntimeError("پاسخ embedding از Gemini قابل خواندن نیست.")
        vectors.append(vec)
    arr = np.asarray(vectors, dtype="float32")
    faiss.normalize_L2(arr)
    return arr


def build_rag_index(api_key: str, uploaded_files):
    if not faiss:
        raise RuntimeError("faiss-cpu نصب نشده است.")
    client = get_gemini_client(api_key)
    if client is None:
        raise RuntimeError("google-genai نصب نشده است.")

    all_chunks = []
    for f in uploaded_files:
        pages = extract_pdf_pages(f)
        for c in chunk_pages(pages):
            c["source"] = f.name
            all_chunks.append(c)

    if not all_chunks:
        raise RuntimeError("از PDFها متن قابل استخراج پیدا نشد.")

    vectors = embed_texts(client, [x["text"] for x in all_chunks])
    index = faiss.IndexFlatIP(vectors.shape[1])
    index.add(vectors)
    return index, all_chunks


def retrieve(index, chunks, client, question: str, k: int = 5):
    qv = embed_texts(client, [question])
    scores, ids = index.search(qv, min(k, len(chunks)))
    results = []
    for score, idx in zip(scores[0], ids[0]):
        if idx >= 0:
            item = dict(chunks[idx])
            item["score"] = float(score)
            results.append(item)
    return results


def general_answer(question: str) -> str:
    q = question.lower()
    if "قانون اهم" in q or "ohm" in q:
        return "قانون اهم رابطه V = I×R است؛ اگر دو مقدار را داشته باشید، مقدار سوم از همین رابطه به‌دست می‌آید."
    if "خازن" in q:
        return "برای خازن، Q=C×V و انرژی ذخیره‌شده E=½CV² است. در اتصال سری ظرفیت معادل کاهش می‌یابد و در موازی افزایش می‌یابد."
    if "دیود" in q:
        return "دیود معمولاً جریان را در یک جهت عبور می‌دهد. در بایاس مستقیم، افت ولتاژ به نوع دیود و جریان وابسته است."
    if "ترانزیستور" in q:
        return "ترانزیستور می‌تواند برای تقویت یا به‌عنوان کلید استفاده شود. در حالت کلید، وضعیت قطع و اشباع اهمیت زیادی دارد."
    return "برای این سؤال، پاسخ عمومی کافی نیست. یک PDF آموزشی مرتبط بارگذاری کنید تا Voltix پاسخ را با ارجاع صفحه از محتوای همان کتاب تولید کند."


def ask_gemini(client, question: str, contexts: List[Dict]) -> str:
    context_text = "\n\n".join(
        f"[منبع: {c['source']}، صفحه {c['page']}]\n{c['text']}" for c in contexts
    )
    prompt = f"""
تو دستیار آموزشی فارسی Voltix برای هنرجویان ۱۵ تا ۱۸ ساله الکترونیک هستی.
پاسخ را ساده، دقیق و مرحله‌به‌مرحله به فارسی بده.
اگر از متن منابع زیر استفاده می‌کنی، شماره صفحه را در انتهای جمله یا پاراگراف مربوط ذکر کن.
اگر پاسخ در منابع نیست، صریح بگو که در منابع بارگذاری‌شده پیدا نشد و سپس در صورت امکان پاسخ عمومی و کوتاه ارائه کن.
از ساختن شماره صفحه یا منبع خیالی خودداری کن.

سؤال:
{question}

منابع بازیابی‌شده:
{context_text}
"""
    response = client.models.generate_content(
        model="gemini-2.5-flash",
        contents=prompt,
    )
    text = getattr(response, "text", None)
    if not text:
        raise RuntimeError("پاسخ متنی از Gemini دریافت نشد.")
    return text


def tab_ai():
    st.header("🤖 دستیار هوشمند Voltix")
    st.caption("RAG با Gemini + استخراج متن PDF + FAISS. برای استفاده واقعی، کلید Gemini را خودتان وارد کنید؛ کلید داخل کد ذخیره نمی‌شود.")

    with st.sidebar:
        st.markdown("### ⚙️ تنظیمات هوش مصنوعی")
        api_key = st.text_input("کلید Gemini API", type="password", key="gemini_key")
        st.caption("می‌توانید کلید را از Google AI Studio بگیرید. سهمیه رایگان Gemini بسته به حساب و مدل ممکن است تغییر کند.")

    files = st.file_uploader(
        "📖 کتاب‌های الکترونیک فارسی را به‌صورت PDF بارگذاری کنید",
        type=["pdf"],
        accept_multiple_files=True,
    )

    c1, c2 = st.columns([1, 2])
    with c1:
        build = st.button("ساخت/بازسازی پایگاه دانش", type="primary", use_container_width=True)

    if build:
        if not api_key:
            st.error("ابتدا کلید Gemini API را وارد کنید.")
        elif not files:
            st.error("حداقل یک PDF بارگذاری کنید.")
        else:
            with st.spinner("در حال استخراج PDF، ساخت chunk و embedding..."):
                try:
                    index, chunks = build_rag_index(api_key, files)
                    st.session_state["rag_index"] = index
                    st.session_state["rag_chunks"] = chunks
                    st.session_state["rag_file_names"] = [f.name for f in files]
                    st.success(f"پایگاه دانش آماده شد: {len(chunks)} قطعه متن.")
                except Exception as e:
                    st.error(f"ساخت پایگاه دانش انجام نشد: {e}")

    if st.session_state.get("rag_file_names"):
        st.info("کتاب‌های فعال: " + "، ".join(st.session_state["rag_file_names"]))

    question = st.text_area("سؤال خود را بنویسید", placeholder="مثلاً چرا در اتصال سری جریان همه مقاومت‌ها یکسان است؟")
    ask = st.button("پرسش از Voltix", type="primary")

    if ask:
        if not question.strip():
            st.warning("سؤال را وارد کنید.")
            return
        if not api_key:
            st.error("برای پاسخ هوشمند Gemini، کلید API لازم است.")
            return

        try:
            client = get_gemini_client(api_key)
            if st.session_state.get("rag_index") is not None:
                contexts = retrieve(
                    st.session_state["rag_index"],
                    st.session_state["rag_chunks"],
                    client,
                    question,
                    k=5,
                )
                answer = ask_gemini(client, question, contexts)
                st.markdown("### پاسخ")
                st.markdown(answer)
                if contexts:
                    st.markdown("### منابع بازیابی‌شده")
                    for c in contexts:
                        st.markdown(f"- **{c['source']} — صفحه {c['page']}**")
            else:
                # بدون PDF: fallback واقعی به مدل Gemini با پرامپت عمومی
                response = client.models.generate_content(
                    model="gemini-2.5-flash",
                    contents=f"به فارسی و آموزشی به این سؤال الکترونیک پاسخ بده، بدون ساختن منبع: {question}",
                )
                answer = getattr(response, "text", None)
                st.markdown("### پاسخ")
                st.markdown(answer or general_answer(question))
        except Exception as e:
            st.warning(f"Gemini در دسترس نبود؛ پاسخ عمومی نمایش داده شد. جزئیات: {e}")
            st.markdown("### پاسخ عمومی")
            st.write(general_answer(question))


# ============================================================
# تب ۵: ابزارهای اضافی
# ============================================================

def tab_extra():
    st.header("🛠️ ابزارهای اضافی")
    sub = st.tabs(["تبدیل واحد", "جدول رنگ مقاومت", "مبدل کد خازن"])

    with sub[0]:
        st.subheader("تبدیل واحد")
        category = st.selectbox("دسته", ["مقاومت", "خازن", "ولتاژ", "جریان"])
        units = {
            "مقاومت": ["Ω", "kΩ", "MΩ"],
            "خازن": ["pF", "nF", "µF", "mF", "F"],
            "ولتاژ": ["mV", "V", "kV"],
            "جریان": ["µA", "mA", "A"],
        }[category]
        c1, c2 = st.columns(2)
        value = c1.number_input("مقدار", value=1.0, step=.1)
        from_u = c1.selectbox("از", units)
        to_u = c2.selectbox("به", units)
        base = unit_to_base(value, from_u, category)
        factors = {
            "مقاومت": {"Ω": 1, "kΩ": 1e3, "MΩ": 1e6},
            "خازن": {"pF": 1e-12, "nF": 1e-9, "µF": 1e-6, "mF": 1e-3, "F": 1},
            "ولتاژ": {"mV": 1e-3, "V": 1, "kV": 1e3},
            "جریان": {"µA": 1e-6, "mA": 1e-3, "A": 1},
        }
        out = base / factors[category][to_u]
        result_box(f"<b>{value:g} {from_u} = {out:.8g} {to_u}</b>")

    with sub[1]:
        st.subheader("جدول کد رنگی مقاومت")
        data = []
        for name, (digit, mult, tol, _) in RESISTOR_COLORS.items():
            data.append({
                "رنگ": name,
                "رقم": "—" if digit is None else digit,
                "ضریب": mult,
                "تلورانس": "—" if tol is None else f"±{tol}%",
            })
        df = pd.DataFrame(data)
        st.dataframe(df, use_container_width=True, hide_index=True)
        csv = df.to_csv(index=False).encode("utf-8-sig")
        st.download_button("⬇️ دانلود جدول برای چاپ/اکسل", csv, "voltix_resistor_color_table.csv", "text/csv")

    with sub[2]:
        st.subheader("مبدل کد خازن سه‌رقمی")
        code = st.text_input("کد سه‌رقمی", placeholder="مثلاً 104")
        if code:
            if re.fullmatch(r"\d{3}", code):
                a, b, m = int(code[0]), int(code[1]), int(code[2])
                pf = (10 * a + b) * (10 ** m)
                result_box(f"<b>{code} = {fmt(pf, 'pF')}</b> = {fmt(pf * 1e-6, 'µF')}")
            else:
                st.error("کد باید دقیقاً سه رقم باشد.")
        st.caption("این تبدیل برای کدهای رایج سه‌رقمی بر پایه pF است؛ کدهای خاص سازنده ممکن است قواعد دیگری داشته باشند.")


# ============================================================
# خروجی HTML قابل دانلود
# ============================================================

def html_download():
    """یک صفحه معرفی مستقل برای Voltix که بدون نصب هم قابل ذخیره/اشتراک‌گذاری است."""
    html = """<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Voltix — آزمایشگاه الکترونیک</title>
<style>
body{font-family:Tahoma,Arial,sans-serif;background:#f3f7fb;color:#183247;line-height:2;margin:0}
main{max-width:900px;margin:30px auto;padding:24px}
.card{background:white;border:1px solid #dce6f0;border-radius:18px;padding:22px;margin:14px 0}
h1{font-size:36px} .tag{display:inline-block;background:#e7f1ff;padding:4px 12px;border-radius:99px}
</style></head>
<body><main>
<div class="card"><h1>⚡ Voltix</h1>
<p>آزمایشگاه و دستیار آموزشی الکترونیک برای هنرجویان هنرستان.</p>
<span class="tag">فارسی</span> <span class="tag">RTL</span> <span class="tag">موبایل‌فرندلی</span>
</div>
<div class="card"><h2>امکانات</h2>
<ul>
<li>ماشین‌حساب قانون اهم، مقاومت، تقسیم ولتاژ، LED، خازن و فیلتر RC</li>
<li>مرجع قطعات و پایه‌ها</li>
<li>آموزش تعاملی مدارهای سری و موازی، AC/DC، ترانزیستور و دیود</li>
<li>دستیار هوشمند Gemini با RAG و ارجاع صفحه PDF</li>
<li>تبدیل واحد و ابزارهای کد قطعات</li>
</ul></div>
<div class="card"><h2>سازندگان</h2><p>امیرحسین احسانی<br>سهیل هیبتیان</p></div>
<div class="card"><p>این فایل HTML یک صفحه معرفی مستقل است؛ برای اجرای کامل ابزارها، فایل app.py را با Streamlit اجرا کنید.</p></div>
</main></body></html>"""
    st.download_button(
        "⬇️ دانلود صفحه HTML معرفی Voltix",
        data=html.encode("utf-8"),
        file_name="voltix.html",
        mime="text/html",
        use_container_width=True,
    )


# ============================================================
# اجرای برنامه
# ============================================================

if "rag_index" not in st.session_state:
    st.session_state["rag_index"] = None
if "rag_chunks" not in st.session_state:
    st.session_state["rag_chunks"] = []
if "rag_file_names" not in st.session_state:
    st.session_state["rag_file_names"] = []

st.markdown(
    """
<div class="hero">
  <div class="hero-title">⚡ Voltix</div>
  <div class="hero-subtitle">
    آزمایشگاه و دستیار آموزشی الکترونیک برای هنرجویان هنرستان؛
    رایگان، فارسی، راست‌چین و مناسب موبایل.
  </div>
</div>
""",
    unsafe_allow_html=True,
)

with st.sidebar:
    st.markdown("## ⚡ Voltix")
    st.caption("آزمایشگاه الکترونیک")
    st.divider()
    st.markdown("**سازندگان**")
    st.write("امیرحسین احسانی")
    st.write("سهیل هیبتیان")
    st.divider()
    st.markdown("### 🌐 خروجی HTML")
    html_download()
    st.divider()
    st.caption("برای استفاده از دستیار هوشمند، کلید Gemini API را فقط در بخش دستیار وارد کنید؛ کلید در کد ذخیره نشده است.")

tabs = st.tabs([
    "🧮 ماشین‌حساب‌های الکترونیک",
    "📚 مرجع قطعات",
    "🎓 آموزش تعاملی",
    "🤖 دستیار هوشمند",
    "🛠️ ابزارهای اضافی",
])

with tabs[0]:
    tab_calculators()

with tabs[1]:
    tab_reference()

with tabs[2]:
    tab_learning()

with tabs[3]:
    tab_ai()

with tabs[4]:
    tab_extra()

st.markdown(
    '<div class="footer">Voltix © آموزشی — ساخته‌شده برای یادگیری الکترونیک با ابزارهای رایگان وب</div>',
    unsafe_allow_html=True,
)
